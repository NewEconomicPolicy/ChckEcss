#-------------------------------------------------------------------------------
# Name:        initialise_check_ecosse.py
# Purpose:     script to read setup and configuration files and write user selections back to the configuration file
# Author:      Mike Martin
# Created:     31/03/2020
# Licence:     <your licence>
#-------------------------------------------------------------------------------
#!/usr/bin/env python

__prog__ = 'initialise_check_ecosse.py'
__version__ = '0.0.0'

# Version history
# ---------------
# 
# import csv
import os
from analyse_ecosse_output import format_out_files
import json
from time import sleep

sleepTime= 5

def initiation(form):
    '''
    this function is called to initiate the programme to process non-GUI settings
    '''
    # retrieve settings
    # =================
    chk_ecsse_str = 'check_ecosse'
    form.settings = _read_setup_file(chk_ecsse_str)
    form.settings['config_file'] = os.path.normpath(form.settings['config_dir'] + '/' + chk_ecsse_str + '_results.json')

    return

def _read_setup_file(chk_ecsse_str):
    '''
    read settings used for programme from the setup file, if it exists,
    or create setup file using default values if file does not exist
    '''
    func_name =  __prog__ +  ' _read_setup_file'

    # validate setup file
    # ===================
    fname_setup = chk_ecsse_str + '_setup.json'

    setup_file = os.path.join(os.getcwd(), fname_setup)
    if os.path.exists(setup_file):
        try:
            with open(setup_file, 'r') as fsetup:
                setup = json.load(fsetup)

        except (OSError, IOError) as e:
                sleep(sleepTime)
                exit(0)
    else:
        setup = _write_default_setup_file(setup_file)
        print('Read default setup file ' + setup_file)

    # initialise vars
    # ===============
    settings = setup['setup']
    settings_list = ['config_dir', 'fname_png']
    for key in settings_list:
        if key not in settings:
            print('*** Error *** setting {} is required in setup file {} '.format(key, setup_file))
            sleep(sleepTime)
            exit(0)
    settings['chk_ecsse_str'] = chk_ecsse_str

    # make sure directories exist for configuration file
    # ==================================================
    config_dir = settings['config_dir']
    if not os.path.lexists(config_dir):
        os.makedirs(config_dir)

    # report settings
    # ===============
    print('Resource locations:')
    print('\tconfiguration file: ' + config_dir)
    print('')

    return settings

def _write_default_setup_file(setup_file):
    """
    stanza if setup_file needs to be created
    """
    root_dir, dummy  = os.path.split(os.getcwd())
    _default_setup = {
        'setup': {
            'config_dir': os.path.join(root_dir, 'config'),
            'fname_png':  os.path.join(root_dir, 'Images', 'Tree_of_life.PNG')
        }
    }
    # create setup file
    # =================
    with open(setup_file, 'w') as fsetup:
        json.dump(_default_setup, fsetup, indent=2, sort_keys=True)

    return _default_setup

def read_config_file(form):

    # read settings from the config file if it exists and create default if not
    # =========================================================================
    config_file = form.settings['config_file']
    if os.path.exists(config_file):
        try:
            with open(config_file, 'r') as fconfig:
                config = json.load(fconfig)
        except (OSError, IOError) as e:
                print(e)
                return False
    else:
        # stanza if config_file needs to be created
        # =========================================
        out_res_dir = ''
        ref_dir   = ''   # directory containing reference outputs
        targ_dir  = ''   # target directory of output files to be compared
        rslts_dir = ''   # results are put here
        _default_config = {
            'Directories': {
                'ref_dir': ref_dir,
                'summary_only': False,
                'use_targ2': False,
                'targ1_dir': targ_dir,
                'targ2_dir': targ_dir,
                'rslts_dir': rslts_dir,
                'water_dep': '50.0'
                }
            }
        # if config file does not exist then create it...
        with open(config_file, 'w') as fconfig:
            json.dump(_default_config, fconfig, indent=2, sort_keys=True)
            config = _default_config

    grp = 'Directories'
    ref_dir = os.path.normpath(config[grp]['ref_dir'])
    form.w_lbl03.setText(ref_dir)

    form.w_smmry_only.setChecked(config[grp]['summary_only'])
    form.w_targ2_also.setChecked(config[grp]['use_targ2'])

    targ1_dir = os.path.normpath(config[grp]['targ1_dir'])
    form.w_lbl04.setText(targ1_dir)

    targ2_dir = os.path.normpath(config[grp]['targ2_dir'])
    form.w_lbl06.setText(targ2_dir)

    rslts_dir = os.path.normpath(config[grp]['rslts_dir'])
    form.w_lbl13.setText(rslts_dir)
    if not os.path.exists(rslts_dir):
        print('Results directory ' + rslts_dir + ' does not exist')

    form.w_water_dep.setText(str(config[grp]['water_dep']))
    form.w_lbl05.setText(format_out_files(form))
    form.w_lbl07.setText(format_out_files(form, target_flag = 'targ2'))

    return

def write_config_file(form):

    config_file = form.settings['config_file']

    grp = 'Directories'
    config = {
        'Directories': {
            'ref_dir': form.w_lbl03.text(),
            'summary_only':  form.w_smmry_only.isChecked(),
            'use_targ2': form.w_targ2_also.isChecked(),
            'targ1_dir': form.w_lbl04.text(),
            'targ2_dir': form.w_lbl06.text(),
            'rslts_dir': form.w_lbl13.text(),
            'water_dep': form.w_water_dep.text()
            }
        }
    with open(config_file, 'w') as fconfig:
        json.dump(config, fconfig, indent=2, sort_keys=True)

    return
