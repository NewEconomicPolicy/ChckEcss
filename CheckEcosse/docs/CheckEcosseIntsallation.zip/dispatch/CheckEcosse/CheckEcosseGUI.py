#-------------------------------------------------------------------------------
# Name:
# Purpose:     GUI front end to enable checking of Ecosse outputs
# Author:      Mike Martin
# Created:     8/3/2016
# Licence:     <your licence>
#-------------------------------------------------------------------------------
#!/usr/bin/env python

__prog__ = 'CheckEcosseGUI.py'
__version__ = '0.0.1'
__author__ = 's03mm5'

import os
import sys

from PyQt5.QtCore import Qt
from PyQt5.QtGui import QPixmap, QFont
from PyQt5.QtWidgets import QLabel, QWidget, QApplication, QHBoxLayout, QVBoxLayout, QGridLayout, QLineEdit, \
                                QPushButton, QCheckBox, QFileDialog, QTextEdit

from analyse_site_spec_dir import Analysis, check_identical_files, check_input_file_compliance
import analyse_ecosse_output
from analyse_ecosse_output import format_out_files
from initialise_check_ecosse import read_config_file, write_config_file, initiation
from generate_charts_funcs import generate_charts
from common_funcs import run_site_specific
from set_up_logging import OutLog

class Form(QWidget):

    def __init__(self, parent=None):

        super(Form, self).__init__(parent)

        initiation(self)
        font = QFont(self.font())
        font.setPointSize(font.pointSize() + 2)
        self.setFont(font)

        # The layout is done with the QGridLayout
        grid = QGridLayout()
        grid.setSpacing(10)	# set spacing between widgets

        # line 3 - directory containing reference outputs
        # ======
        w_ref_dir = QPushButton("Reference dir")
        helpText = 'Directory with verified Ecosse output'
        w_ref_dir.setToolTip(helpText)

        grid.addWidget(w_ref_dir, 3, 0)
        w_ref_dir.clicked.connect(self.fetchRefDir)

        w_lbl03 = QLabel('')
        grid.addWidget(w_lbl03, 3, 1, 1, 5)
        self.w_lbl03 = w_lbl03

        # lines 4 and 5 - widget set for first Target dir
        # ===============================================
        w_targ1_dir = QPushButton("Target 1 dir")
        helpText = 'First directory consisting of ECOSSE outputs against which reference outputs will be compared'
        w_targ1_dir.setToolTip(helpText)
        grid.addWidget(w_targ1_dir, 4, 0)
        w_targ1_dir.clicked.connect(self.fetchTarg1Dir)

        w_lbl04 = QLabel()
        grid.addWidget(w_lbl04, 4, 1, 1, 5)
        self.w_lbl04 = w_lbl04

        # report on numbers of .OUT files
        # ===============================
        self.w_lbl05 = QLabel()
        grid.addWidget(self.w_lbl05, 5, 1, 1, 5)

        # line 5
        # ======
        w_targ2_also = QCheckBox('Use target 2 also')
        w_targ2_also.setChecked(True)
        grid.addWidget(w_targ2_also, 6, 0, 1, 2)
        self.w_targ2_also = w_targ2_also

        # lines 6 and 7 - widget set for first Target dir - second target directory of output files to be compared
        # ===============================================
        w_targ2_dir = QPushButton("Target 2 dir")
        helpText = 'Second directory consisting of ECOSSE outputs against which reference outputs will be compared'
        w_targ2_dir.setToolTip(helpText)
        grid.addWidget(w_targ2_dir, 7, 0)
        w_targ2_dir.clicked.connect(self.fetchTarg2Dir)

        w_lbl06 = QLabel()
        grid.addWidget(w_lbl06, 7, 1, 1, 5)
        self.w_lbl06 = w_lbl06

        self.w_lbl07 = QLabel()
        grid.addWidget(self.w_lbl07, 8, 1, 1, 5)

        # spacer
        w_lbl09 = QLabel()
        grid.addWidget(w_lbl09, 9, 1, 1, 5)

        # line 10
        # =======
        w_smmry_only = QCheckBox('Compare SUMMARY.OUT only')
        w_smmry_only.setChecked(True)
        # w_smmry_only.setEnabled(False)
        grid.addWidget(w_smmry_only, 10, 0, 1, 2)
        self.w_smmry_only = w_smmry_only

        # line 10
        # =======
        w_use_fseg = QCheckBox('Prepend last folder')
        helpText = 'Prepend last folder name to chart series labels e.g. if selected then \n'\
                    'D:\\Marta\\UK_site_specific_sims\mintill\\NH9453 would result in mintill_NH9453 instead of NH9453'
        w_use_fseg.setToolTip(helpText)
        w_use_fseg.setChecked(True)
        grid.addWidget(w_use_fseg, 10, 2, 1, 2)
        self.w_use_fseg = w_use_fseg

         # line 16
        # ========
        lbl16 = QLabel('Water depth (cms):')
        grid.addWidget(lbl16, 10, 4)
        lbl16.setAlignment(Qt.AlignRight)

        w_water_dep = QLineEdit()
        helpText = 'Depth for soil water chart [cm] e.g. 50, 100, 300 (max)'
        w_water_dep.setToolTip(helpText)
        grid.addWidget(w_water_dep, 10, 5)
        self.w_water_dep = w_water_dep

        # line 13 - widget set for Results dir  - put results here
        # ====================================
        w_rslts_dir = QPushButton("Results file dir")
        helpText = 'Directory to which results, i.e. the Excel file will be written'
        w_rslts_dir.setToolTip(helpText)
        grid.addWidget(w_rslts_dir, 13, 0)
        w_rslts_dir.clicked.connect(self.fetchRsltsDir)

        w_lbl13 = QLabel()
        grid.addWidget(w_lbl13, 13, 1, 1, 5)
        self.w_lbl13 = w_lbl13

        # line 19
        # =======
        w_check_carbon = QPushButton("Chart OUT files")
        helpText = 'Perform comparison of reference, target 1 and target 2 Carbon and Nitrogen related *.OUT files\n' + \
            '- generates charts of carbon and nitrogen metric sets'
        w_check_carbon.setToolTip(helpText)
        w_check_carbon.clicked.connect(self.chartOutFilesClicked)  # signal/slot
        grid.addWidget(w_check_carbon, 19, 0)

        w_indentical_files = QPushButton("Diff input files")
        helpText = 'Report whether all .dat and .txt files for reference and target 1 directories are identical or different'
        w_indentical_files.setToolTip(helpText)
        w_indentical_files.clicked.connect(self.diffInputFilesClicked)
        grid.addWidget(w_indentical_files, 19, 1)

        w_compliance = QPushButton("Check input files")
        helpText = 'Check necessary input files are present and compliant: fnames.dat, management.txt, site.txt and soil.txt'
        w_compliance.setToolTip(helpText)
        w_compliance.clicked.connect(self.checkInputFileComplianceClicked)
        grid.addWidget(w_compliance, 20, 1)

        w_lite_check = QPushButton("Diff output files")
        helpText = 'Perform comparison of reference and target 1 *.OUT files' + \
                   '- only reports whether same or different'
        w_lite_check.setToolTip(helpText)
        w_lite_check.clicked.connect(self.diffOutputFilesClicked)  # signal/slot
        grid.addWidget(w_lite_check, 19, 2)

        w_check_files = QPushButton("Compare OUT files")
        helpText = 'Perform comparison of reference and target 1 *.OUT files' + \
                   '- generates Excel spreadsheet of differences'
        w_check_files.setEnabled(False)
        w_check_files.setToolTip(helpText)
        w_check_files.clicked.connect(self.compareOutFilesClicked)  # signal/slot
        grid.addWidget(w_check_files, 20, 2)

        run_tests = QPushButton("Directory scan")
        helpText = 'Summarises files in reference directory'
        run_tests.setToolTip(helpText)
        run_tests.clicked.connect(self.directoryScanClicked)
        grid.addWidget(run_tests, 19, 4)

        exit = QPushButton("Exit", self)
        exit.clicked.connect(self.exitClicked)
        grid.addWidget(exit, 19, 6)

        w_run_ss = QPushButton("Run SS", self)
        helpText = 'runs site specific mode only for 30 years with vigour'
        w_run_ss.setToolTip(helpText)
        w_run_ss.setEnabled(False)
        w_run_ss .clicked.connect(self.runSiteSpecificClicked)
        grid.addWidget(w_run_ss , 20, 6)

        # LH vertical box consists of png image
        # =====================================
        lh_vbox = QVBoxLayout()

        lbl20 = QLabel()
        lbl20.setPixmap(QPixmap(self.settings['fname_png']))
        lh_vbox.addWidget(lbl20)

        # add grid consisting of combo boxes, labels and buttons to RH vertical box
        # =========================================================================
        rh_vbox = QVBoxLayout()
        rh_vbox.addLayout(grid)

        # add reporting
        # =============
        bot_hbox = QHBoxLayout()
        w_report = QTextEdit()
        w_report.verticalScrollBar().minimum()
        w_report.setMinimumHeight(175)
        w_report.setMinimumWidth(1000)
        w_report.setStyleSheet('font: bold 10.5pt Courier')  # big jump to 11pt
        ''' 
        w_report.setStyleSheet('font: 9pt Courier')
        w_report.setStyleSheet('font: normal 12px Calabri; color: blue;'
                               'background-color: yellow;'
                               'selection-color: yellow;'
                               'selection-background-color: blue;')
        '''
        bot_hbox.addWidget(w_report, 1)
        self.w_report = w_report
        sys.stdout = OutLog(self.w_report, sys.stdout)
        # sys.stderr = OutLog(self.w_report, sys.stderr, QColor(255, 0, 0))

        # add LH and RH vertical boxes to main horizontal box
        # ===================================================
        main_hbox = QHBoxLayout()
        main_hbox.setSpacing(10)
        main_hbox.addLayout(lh_vbox)
        main_hbox.addLayout(rh_vbox, stretch = 1)

        # feed horizontal boxes into the window
        # =====================================
        outer_layout = QVBoxLayout()
        outer_layout.addLayout(main_hbox)
        outer_layout.addLayout(bot_hbox)
        self.setLayout(outer_layout)

        # posx, posy, width, height
        self.setGeometry(125, 125, 690, 250)
        self.setWindowTitle('Check and compare Ecosse inputs and outputs')

        read_config_file(self)

    # =======================================
    def checkInputFileComplianceClicked(self):
        # check compliance of input files: fnames.dat, management.txt, site.txt and soil.txt
        check_input_file_compliance(self)

    def diffInputFilesClicked(self):
        # report whether .dat and .txt files for reference and target 1 directories are identical or different
        check_identical_files(self)    

    def diffOutputFilesClicked(self):
        # perform shallow comparison of reference and target 1 *.OUT files
        check_identical_files(self, file_types = 'output')

    def chartOutFilesClicked(self):
        # generates charts of carbon and nitrogen metric sets
        generate_charts(self)

    def compareOutFilesClicked(self):
        # generate Excel spreadsheet of differences between reference and target 1 *.OUT files
        analysis = analyse_ecosse_output.Analysis(self)   # initialises object
        analysis.check_ecosse_files(self)  # creates a summary file

    def directoryScanClicked(self):
        # summarises files in reference directory
        analysis = Analysis(self)           # initialises object
        analysis.check_these_files(self)    # creates summary file

    def runSiteSpecificClicked(self):
        # runs site specific mode only for 30 years with vigour
        run_site_specific(self)

    def fetchRefDir(self):
        #
        fname = self.w_lbl03.text()
        fname = QFileDialog.getExistingDirectory(self, 'Select directory', fname)
        if fname != '':
            fname = os.path.normpath(fname)
            self.w_lbl03.setText(fname)
            self.w_lbl05.setText(format_out_files(self))

    def fetchTarg1Dir(self):
        #
        fname = self.w_lbl04.text()
        fname = QFileDialog.getExistingDirectory(self, 'Select directory', fname)
        if fname != '':
            fname = os.path.normpath(fname)
            self.w_lbl04.setText(fname)
            self.w_lbl05.setText(format_out_files(self))

    def fetchTarg2Dir(self):
        #
        fname = self.w_lbl06.text()
        fname = QFileDialog.getExistingDirectory(self, 'Select directory', fname)
        if fname != '':
            fname = os.path.normpath(fname)
            self.w_lbl06.setText(fname)
            self.w_lbl07.setText(format_out_files(self, target_flag = 'targ2'))

    def fetchRsltsDir(self):
        #
        fname = self.w_lbl13.text()
        fname = QFileDialog.getExistingDirectory(self, 'Select directory', fname)
        if fname != '':
            fname = os.path.normpath(fname)
            self.w_lbl13.setText(fname)

    def exitClicked(self):
        # write last path selections
        write_config_file(self)
        self.close()

def main():

    app = QApplication(sys.argv)  # create QApplication object
    form = Form()     # instantiate form
    form.show()       # paint form
    sys.exit(app.exec_())   # start event loop

if __name__ == '__main__':
    main()
