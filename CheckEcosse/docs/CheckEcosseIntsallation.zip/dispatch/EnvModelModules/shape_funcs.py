"""
#-------------------------------------------------------------------------------
# Name:
# Purpose:     Collection of functions relating to shapefiles
# Author:      Mike Martin
# Created:     11/12/2015
# Licence:     <your licence>
#-------------------------------------------------------------------------------
#
"""

__prog__ = 'shape_funcs2.py'
__version__ = '0.0.0'
__author__ = 's03mm5'

import os
import glob
import shapefile as pyshp
import math
import locale

notReq = 'NotReq'

def create_lookup_dict(shp_dir, show_message_flag = True, lenAdmNamesLim = 2):

    # build dictionary of countries and corresponding three letter codes
    cntry_lookup_dict = {}
    if not os.path.isdir(shp_dir):
        print('Shape directory ' + shp_dir + ' must exist')
        return {}

    for country in os.listdir(shp_dir):   # get list of country folders in this directory e.g. China, Poland, UK
        country_path = os.path.join(shp_dir, country)
        if os.path.isdir(country_path):
            admNames = glob.glob(country_path + '/*_adm*.shp')
            lenAdmNames = len(admNames)
            if lenAdmNames >= lenAdmNamesLim:

                country_code = os.path.basename(admNames[0])[0:3]

                # look for province level shape file then add to dictionary
                if show_message_flag:
                    print('Processing ' + country)
                shp_rdr = pyshp.Reader(admNames[0])
                lon_ll, lat_ll, lon_ur, lat_ur = shp_rdr.bbox
                area = calculate_area(shp_rdr.bbox)

                tmp_list = [country_code] + [lon_ll, lat_ll, lon_ur, lat_ur, round(area), lenAdmNames]
                cntry_lookup_dict.update({country:tmp_list})

    return cntry_lookup_dict

def _getPolys(lgr,shpes):

    func_name =  __prog__ + ' _getPolys'


    lgr.info('Function: {0}\tnumber of shapes: {1}'.format(func_name,len(shpes)))
    # for now just return the first polygon

    return shpes[-1].points

def _getPoly(lgr,shpe):

    func_name =  __prog__ + ' _getPoly'
    # stand in - should return bounding boxes
    parts = shpe.parts

    lgr.info('Function: {0}\tnumber of parts: {1}'.format(func_name,len(parts)))
    # for now just return the first polygon
    if len(parts) > 1:
        return shpe.points[0: parts[1]]
    else:
        return shpe.points

def get_shape_file_info(shp_file):

    func_name =  __prog__ + '  get_shape_file_info'

    if not os.path.isfile(shp_file):
        return [], []

    # create Reader object and pass the name of an existing shapefile
    shp_rdr = pyshp.Reader(shp_file)
    # bbox = shp_rdr.bbox
    # flds = shp_rdr.fields
    shpes = shp_rdr.shapes()

    recs = shp_rdr.records()
    nrecs = len(recs); nshpes = len(shpes)
    if nshpes != nrecs:
        print('Number of shapes {0:d} does not match number of records {1:d} in DBF file for shapefile {2:s}'
              .format(nshpes,nrecs,shp_file))
        return [], []

    return shpes, recs

def _getShpe(shp_dir, country, abbrev, level, province = notReq, department = notReq,
                                        district = notReq, canton = notReq):
    """
    # get required polygon for a given province or department
    # level 1 consists of provinces/regions
    # level 2 departments/prefectures
    # level 3 counties/districts
    # level 4 cantons
    # level 5 communes
    """
    func_name =  __prog__ + ' _getShpe'

    admFname = '_adm' + str(level) + '.shp'
    file_name = os.path.join(shp_dir + '/' + country, abbrev + admFname)
    if not os.path.isfile(file_name):
        return -1

    # create Reader object and pass the name of an existing shapefile
    shp_rdr = pyshp.Reader(file_name)
    # bbox = shp_rdr.bbox
    # flds = shp_rdr.fields
    shpes = shp_rdr.shapes()

    recs = shp_rdr.records()
    nrecs = len(recs); nshpes = len(shpes)
    if nshpes != nrecs:
        print('Number of shapes {0:d} does not match number of records {1:d} in DBF file for shapefile {2:s}'
              .format(nshpes,nrecs,file_name))
        return -1
    # construct dictionary consisting of names of areas (e.g. province/department/district etc.)
    # and corresponding bounding boxes
    subdiv_dict = {}
    # extract names
    shpe = -1
    for irec in range(nrecs):
        subdiv = notReq  # default
        # country level - the coarsest level therefore take first record
        if level == 0:
            shpe = shpes[irec]
            break
        # province level - the next coarsest level therefore no requirement to check other fields
        elif level == 1:
            if province == recs[irec][4]:
                # poly = shpes[irec].points
                # parts = shpes[irec].parts
                shpe = shpes[irec]
                break
        # department/prefecture - therefore filter out irrelevant i.e. non-parent provinces
        elif level == 2:
            if province == recs[irec][4] and department == recs[irec][6]:
                # poly = shpes[irec].points
                # parts = shpes[irec].parts
                shpe = shpes[irec]
                break
        elif level == 3:
            if province == recs[irec][4] and department == recs[irec][6] and district == recs[irec][8]:
                # poly = shpes[irec].points
                # parts = shpes[irec].parts
                shpe = shpes[irec]
                break  # field name NAME_3, column I
        elif level == 4:
            if province == recs[irec][4] and department == recs[irec][6] and \
                                district == recs[irec][8] and canton == recs[irec][10]:
                # poly = shpes[irec].points
                # parts = shpes[irec].parts
                shpe = shpes[irec]
                break
        elif level == 5:
                pass
    if shpe == -1:
        print('Func: {0} problem: Could not find province: {1}\tdepartment: {2}\tdistrict: {3}\tlevel: {4}'.
                                format(func_name, province, department, district, level))
    else:
        print('Leaving {0}\tlevel: {1}, number of parts: {2}\tpoints on polygon: {3}\trecord: {4}'.
                                format(func_name, level, len(shpe.parts), len(shpe.points), irec))
    return shpe

def _getSubDivisions(shp_dir,country,abbrev,level, province = notReq, department = notReq,
                                        district = notReq, canton = notReq):

    # get list of level 1 or 2 or 3 or 4 or 5 administrative names
    # level 1 consists of provinces/regions
    # level 2 departments/prefectures
    # level 3 counties/districts
    # level 4 cantons
    # level 5 communes
    # and corresponding bounding boxes
    admFname = '_adm' + str(level) + '.shp'
    file_name = os.path.join(shp_dir + '/' + country, abbrev + admFname)
    if not os.path.isfile(file_name):
        # return empty dictionary
        return {}

    # create Reader object and pass the name of an existing shapefile
    shp_rdr = pyshp.Reader(file_name)
    # bbox = shp_rdr.bbox
    # flds = shp_rdr.fields
    shpes = shp_rdr.shapes()

    recs = shp_rdr.records()
    nrecs = len(recs); nshpes = len(shpes)
    if nshpes != nrecs:
        print('Number of shapes {0:d} does not match number of records {1:d} in DBF file for shapefile {2:s}'
              .format(nshpes,nrecs,file_name))
        return -1
    # construct dictionary consisting of names of areas (e.g. province/department/district etc.)
    # and corresponding bounding boxes
    subdiv_dict = {}
    # extract names
    for irec in range(nrecs):
        subdiv = notReq  # default
        # province level - the coarsest level therefore no requirement to look back
        if level == 1:
            subdiv = recs[irec][4]   # field name NAME_1, column E
        # department/prefecture - therefore filter out irrelevant i.e. non-parent provinces
        elif level == 2:
            if province == recs[irec][4]:
                subdiv = recs[irec][6]   # field name NAME_2, column G
        elif level == 3:
            if province == recs[irec][4] and department == recs[irec][6]:
                subdiv = recs[irec][8]   # field name NAME_3, column I
        elif level == 4:
            if province == recs[irec][4] and department == recs[irec][6] and district == recs[irec][8]:
                subdiv = recs[irec][10]   # field name NAME_4, column K
        elif level == 5:
            if province == recs[irec][4] and department == recs[irec][6] and \
                                district == recs[irec][8] and canton == recs[irec][10]:
                subdiv = recs[irec][12]   # field name NAME_5, column M

        if subdiv != notReq:
            bbox = shpes[irec].bbox
            area = calculate_area(bbox)
            bbox.append(area)
            subdiv_dict[subdiv] = bbox

    return subdiv_dict

def get_shps_provinces(shp_file):

    if not os.path.exists(shp_file):
        return ''

     # create Reader object and pass the name of an existing shapefile
    shp_rdr = pyshp.Reader(shp_file)
    # bbox = shp_rdr.bbox
    # flds = shp_rdr.fields
    shpes = shp_rdr.shapes()

    recs = shp_rdr.records()
    nrecs = len(recs); nshpes = len(shpes)
    if nshpes != nrecs:
        print('Number of shapes {0:d} does not match number of records {1:d} in DBF file for shapefile {2:s}'
              .format(nshpes,nrecs,shp_file))
        return -1

    provinces = []
    for rec in recs:
        prov = rec[1]
        if prov not in provinces:
            provinces.append(prov)

    nprovs = len(provinces)

    return '{}, {}'.format(nshpes, nprovs)

def calculate_area(bbox):

    # calculate Zone of earth's sphere i.e. the curved surface of a spherical segment.
    radius_earth = 6371.0 # km average
    pi = 3.14159265
    deg2rad = pi/180.0
    lon_ll, lat_ll, lon_ur, lat_ur = bbox

    # TODO: work out what can happen for southern hemisphere or straddling equator....
    theta2 = lat_ur*deg2rad
    theta1 = lat_ll*deg2rad

    domega = (lon_ur - lon_ll)/360.0

    # area is in square km
    area = 2.0*pi*domega*radius_earth*(radius_earth*(math.sin(theta2) - math.sin(theta1)))

    return area

def format_bbox(bbox, area = 0.0, ndigits = 0):
    """
    format long/lat and area string for display in GUI
    """

    if len(bbox) == 7:
        abbrev, lon_ll, lat_ll, lon_ur, lat_ur, area, nlevels = bbox
    elif len(bbox) == 5:
        lon_ll, lat_ll, lon_ur, lat_ur, area = bbox
    else:
        lon_ll, lat_ll, lon_ur, lat_ur = bbox

    if ndigits == 0:
        locale.setlocale(locale.LC_ALL, '')
        area_out = round(area)
        area_out = locale.format("%d", area_out, grouping=True )
    else:
        area_out = round(area, ndigits)


    return 'LL: {:.2f} {:.2f}\tUR: {:.2f} {:.2f}\tArea: {} km2'\
            .format(lon_ll, lat_ll, lon_ur, lat_ur, area_out)

def compress_shpe_file(shp_file, images_dir):

    func_name =  __prog__ + ' compress_shpe_file'

    if not os.path.isfile(shp_file):
        return -1

    # create Reader object and pass the name of an existing shapefile
    shp_rdr = pyshp.Reader(shp_file)
    # bbox = shp_rdr.bbox
    # flds = shp_rdr.fields
    shpes = shp_rdr.shapes()

    recs = shp_rdr.records()
    nrecs = len(recs); nshpes = len(shpes)
    if nshpes != nrecs:
        print('Number of shapes {0:d} does not match number of records {1:d} in DBF file for shapefile {2:s}'
              .format(nshpes,nrecs,shp_file))
        return -1

    # file to output first ring
    fname = os.path.join(images_dir,'border.csv')
    if not os.path.isfile(fname):
        print('Function: {0}\tfile: {1} does not exist - will create'.format(func_name,fname))
    try:
        fpoly = open(fname,'w')
    except PermissionError:
        print('Function: {0}\tCould not open file: {1}'.format(func_name,fname))
        return 1

    # fetch each shape and map to granular
    granularity = 120.0
    coord_max_val = 999.0
    for nshp, shpe in zip(range(len(shpes)), shpes):
        if nshp > 0:
            break
        print('shape {} with {} parts and {} points'.format(nshp + 1, len(shpe.parts), len(shpe.points)))

        indxs = 0
        for npart, indxe in zip(range(len(shpe.parts)),shpe.parts[1:]):
            if npart > 0:
                break
            lat_max = -coord_max_val
            lat_min = coord_max_val
            lon_max = -coord_max_val
            lon_min = coord_max_val
            gran_points = []
            ring = shpe.points[indxs:indxe ]
            print('ring {} first/last points: {} {}'.format(npart + 1, ring[0],ring[-1]))
            for point in ring:
                lon, lat = point
                if lat > lat_max:
                    lat_max = lat
                if lat < lat_min:
                    lat_min = lat
                if lon > lon_max:
                    lon_max = lon
                if lon < lon_min:
                    lon_min = lon
                nrow = round((90.0 -  lat)*granularity)
                ncol = round((180.0 + lon)*granularity)
                elem = list([ncol,nrow])
                if elem not in gran_points:
                    gran_points.append(elem)
                    fpoly.write('{0},{1},{2},{3}\n'.format(lon,lat,nrow,ncol,nshp))

            print('ring {} with {} points, granular points: {} min/max lon: {} {} min/max lat: {} {}'
                  .format(npart + 1,indxe - indxs, len(gran_points), lon_min, lon_max, lat_min, lat_max))
            indxs = indxe
    fpoly.close()

    print('Leaving {0}'.format(func_name))
    return shpe
